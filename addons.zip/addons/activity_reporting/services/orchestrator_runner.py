#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Orchestrator Agent Runner with Odoo Integration

This runner creates an orchestrator agent that can directly query Odoo data
without needing to communicate with subagents.
"""

import argparse
import json
import os
import sys
import logging
import traceback
from datetime import datetime, timedelta

from agno.agent import Agent
from agno.models.openai.like import OpenAILike
from agno.os import AgentOS
from agno.db.sqlite import SqliteDb


def setup_logging(log_path: str, debug: bool = True):
    """Configure logging"""
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_path, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def get_odoo_connection(config: dict):
    """
    Connect to Odoo database using XML-RPC
    This is a simplified version - in production you'd use proper XML-RPC client
    """
    # For now, return None - we'll add proper Odoo connection later
    # The tools will be registered but won't work until Odoo connection is added
    return None


def create_orchestrator_tools(odoo_conn=None):
    """
    Create callable tools for the orchestrator agent
    These tools query Odoo data directly
    """
    
    def get_projects():
        """Get list of all active projects with their details"""
        # This is a mock implementation
        # In production, this would use odoo_conn to query actual data
        return """Current Projects:
1. Website Redesign (ID: 1)
   - Status: In Progress
   - Progress: 65%
   - Tasks: 12 total, 8 completed
   - Team: 5 members

2. Mobile App Development (ID: 2)
   - Status: In Progress
   - Progress: 40%
   - Tasks: 20 total, 8 completed
   - Team: 8 members

3. Marketing Campaign (ID: 3)
   - Status: In Progress
   - Progress: 80%
   - Tasks: 10 total, 8 completed
   - Team: 3 members

Total: 3 active projects"""
    
    def get_employees():
        """Get list of employees"""
        return """Current Employees:
1. John Smith - Software Engineer (Development Team)
2. Sarah Johnson - Project Manager (Management)
3. Mike Brown - Designer (Design Team)
4. Emma Davis - QA Specialist (QA Team)
5. Alex Wilson - Marketing Manager (Marketing)

Total: 5 employees"""
    
    def get_tasks(project_name: str = None):
        """Get tasks, optionally filtered by project"""
        if project_name:
            return f"""Tasks for project '{project_name}':
1. Design homepage mockup (Completed)
2. Implement user authentication (In Progress)
3. Create database schema (Completed)
4. Write unit tests (To Do)
5. Deploy to staging (To Do)

Total: 5 tasks (2 completed, 1 in progress, 2 to do)"""
        else:
            return """All Tasks:
- Website Redesign: 12 tasks (8 completed, 2 in progress, 2 to do)
- Mobile App: 20 tasks (8 completed, 6 in progress, 6 to do)
- Marketing Campaign: 10 tasks (8 completed, 2 in progress)

Total: 42 tasks across all projects"""
    
    def get_timesheets(days: int = 7):
        """Get timesheet entries for recent days"""
        return f"""Timesheet Summary (Last {days} days):

John Smith: 42 hours
- Website Redesign: 25 hours
- Mobile App: 15 hours
- Admin: 2 hours

Sarah Johnson: 40 hours
- Project Management: 30 hours
- Meetings: 10 hours

Mike Brown: 38 hours
- Website Redesign: 30 hours
- Mobile App: 8 hours

Total team hours: 120 hours"""
    
    def get_calendar_events(days_ahead: int = 7):
        """Get upcoming calendar events"""
        return f"""Upcoming Events (Next {days_ahead} days):

Tomorrow:
- 9:00 AM: Team Standup (All hands)
- 2:00 PM: Client Presentation (Sales team)
- 4:00 PM: Sprint Planning (Dev team)

This Week:
- Wednesday 10:00 AM: Design Review
- Thursday 3:00 PM: All Hands Meeting
- Friday 11:00 AM: Demo Session

Total: 6 upcoming events"""
    
    # Return a dictionary of tools
    return {
        'get_projects': get_projects,
        'get_employees': get_employees,
        'get_tasks': get_tasks,
        'get_timesheets': get_timesheets,
        'get_calendar_events': get_calendar_events,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Path to JSON config")
    args = parser.parse_args()
    
    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    
    log_path = cfg["log_path"]
    setup_logging(log_path, debug=bool(cfg.get("debug_mode", False)))
    log = logging.getLogger("orchestrator")
    
    os.environ.setdefault("AGNO_TELEMETRY", "false")
    
    log.info("=== Orchestrator Agent Starting ===")
    log.info("Agent: %s", cfg.get("agent_name", ""))
    
    # Create LLM model
    model = OpenAILike(
        id=cfg.get("model_name", ""),
        base_url=cfg.get("base_url", ""),
        api_key=cfg.get("api_key", ""),
    )
    
    # Create database
    db = SqliteDb(db_file=cfg.get("db_file", "orchestrator.db"))
    
    # Get Odoo connection (currently None)
    odoo_conn = get_odoo_connection(cfg)
    
    # Create tools
    tools = create_orchestrator_tools(odoo_conn)
    
    # Enhanced instructions with tool usage
    enhanced_instructions = f"""{cfg.get('instructions', '')}

IMPORTANT: You have access to the following tools to query current data:

1. get_projects() - Returns list of all active projects with details
2. get_employees() - Returns list of employees  
3. get_tasks(project_name=None) - Returns tasks, optionally filtered by project name
4. get_timesheets(days=7) - Returns timesheet entries for recent days
5. get_calendar_events(days_ahead=7) - Returns upcoming calendar events

When users ask about projects, employees, tasks, timesheets, or calendar:
1. Call the appropriate tool to get current data
2. Present the information clearly
3. Answer the user's specific question based on the tool results

Example:
User: "What projects are active?"
Your response: Let me check the current projects.
[Call get_projects()]
[Present the results clearly]

NEVER make up project names or data - ALWAYS use the tools to get real information.
"""
    
    # Create agent with tools
    agent = Agent(
        id=cfg.get("agent_name", ""),
        name=cfg.get("agent_name", ""),
        role=cfg.get("agent_role", ""),
        model=model,
        instructions=enhanced_instructions,
        db=db,
        tools=list(tools.values()),  # Register the tools
        add_history_to_context=bool(cfg.get("add_history_to_context", True)),
        add_datetime_to_context=bool(cfg.get("add_datetime_to_context", False)),
        markdown=bool(cfg.get("markdown", True)),
        debug_mode=bool(cfg.get("debug_mode", False)),
        num_history_runs=int(cfg.get("num_history_runs", 5)),
        show_tool_calls=True,  # Show tool calls in responses
    )
    
    log.info("Agent created with %d tools", len(tools))
    log.info("Tools: %s", list(tools.keys()))
    
    # Start agent OS
    agent_os = AgentOS(agents=[agent])
    app = agent_os.get_app()
    
    host = cfg.get("host", "0.0.0.0")
    port = int(cfg.get("port", 8000))
    
    log.info("Serving Orchestrator on http://%s:%s", host, port)
    agent_os.serve(app=app, host=host, port=port, reload=False)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.getLogger("orchestrator").error("Orchestrator crashed: %s", e)
        logging.getLogger("orchestrator").error(traceback.format_exc())
        raise
